package com.i1314i.ourproject.po.javabean;

import java.util.Date;

public class HuiNongShouYe {
    private Integer xinXiId;

    private Double mianJi;

    private Integer shuLiang;

    private String mianJiDanWei;

    private String xiType;

    private Date time;

    private Double nianChanLiang;

    private String nianChanLiangDanWei;

    private Double danChan;

    private String daType;

    private String mingCheng;

    private String beiyong1;

    private String beiyong2;

    private Double beiyong3;

    private Double beiyong4;

    private Integer beiyong5;

    public Integer getXinXiId() {
        return xinXiId;
    }

    public void setXinXiId(Integer xinXiId) {
        this.xinXiId = xinXiId;
    }

    public Double getMianJi() {
        return mianJi;
    }

    public void setMianJi(Double mianJi) {
        this.mianJi = mianJi;
    }

    public Integer getShuLiang() {
        return shuLiang;
    }

    public void setShuLiang(Integer shuLiang) {
        this.shuLiang = shuLiang;
    }

    public String getMianJiDanWei() {
        return mianJiDanWei;
    }

    public void setMianJiDanWei(String mianJiDanWei) {
        this.mianJiDanWei = mianJiDanWei == null ? null : mianJiDanWei.trim();
    }

    public String getXiType() {
        return xiType;
    }

    public void setXiType(String xiType) {
        this.xiType = xiType == null ? null : xiType.trim();
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Double getNianChanLiang() {
        return nianChanLiang;
    }

    public void setNianChanLiang(Double nianChanLiang) {
        this.nianChanLiang = nianChanLiang;
    }

    public String getNianChanLiangDanWei() {
        return nianChanLiangDanWei;
    }

    public void setNianChanLiangDanWei(String nianChanLiangDanWei) {
        this.nianChanLiangDanWei = nianChanLiangDanWei == null ? null : nianChanLiangDanWei.trim();
    }

    public Double getDanChan() {
        return danChan;
    }

    public void setDanChan(Double danChan) {
        this.danChan = danChan;
    }

    public String getDaType() {
        return daType;
    }

    public void setDaType(String daType) {
        this.daType = daType == null ? null : daType.trim();
    }

    public String getMingCheng() {
        return mingCheng;
    }

    public void setMingCheng(String mingCheng) {
        this.mingCheng = mingCheng == null ? null : mingCheng.trim();
    }

    public String getBeiyong1() {
        return beiyong1;
    }

    public void setBeiyong1(String beiyong1) {
        this.beiyong1 = beiyong1 == null ? null : beiyong1.trim();
    }

    public String getBeiyong2() {
        return beiyong2;
    }

    public void setBeiyong2(String beiyong2) {
        this.beiyong2 = beiyong2 == null ? null : beiyong2.trim();
    }

    public Double getBeiyong3() {
        return beiyong3;
    }

    public void setBeiyong3(Double beiyong3) {
        this.beiyong3 = beiyong3;
    }

    public Double getBeiyong4() {
        return beiyong4;
    }

    public void setBeiyong4(Double beiyong4) {
        this.beiyong4 = beiyong4;
    }

    public Integer getBeiyong5() {
        return beiyong5;
    }

    public void setBeiyong5(Integer beiyong5) {
        this.beiyong5 = beiyong5;
    }
}