package com.i1314i.ourproject.po.javabean;

import java.util.Date;

public class QiuGouXinXi {
    private Integer qiuGouId;

    private String chanPinMingCheng;

    private String faBuRen;

    private Double caiGouLiang;

    private String pinZhong;

    private String price;

    private String tel;

    private Date time;

    private String huoYuanDiZhi;

    private String beiyong1;

    private String beiyong2;

    private String shenhe;

    private String yuanyin;

    private String beiyong3;

    private String beiyong4;

    private String beiyong5;

    private Integer bumen;

    public Integer getQiuGouId() {
        return qiuGouId;
    }

    public void setQiuGouId(Integer qiuGouId) {
        this.qiuGouId = qiuGouId;
    }

    public String getChanPinMingCheng() {
        return chanPinMingCheng;
    }

    public void setChanPinMingCheng(String chanPinMingCheng) {
        this.chanPinMingCheng = chanPinMingCheng == null ? null : chanPinMingCheng.trim();
    }

    public String getFaBuRen() {
        return faBuRen;
    }

    public void setFaBuRen(String faBuRen) {
        this.faBuRen = faBuRen == null ? null : faBuRen.trim();
    }

    public Double getCaiGouLiang() {
        return caiGouLiang;
    }

    public void setCaiGouLiang(Double caiGouLiang) {
        this.caiGouLiang = caiGouLiang;
    }

    public String getPinZhong() {
        return pinZhong;
    }

    public void setPinZhong(String pinZhong) {
        this.pinZhong = pinZhong == null ? null : pinZhong.trim();
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price == null ? null : price.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getHuoYuanDiZhi() {
        return huoYuanDiZhi;
    }

    public void setHuoYuanDiZhi(String huoYuanDiZhi) {
        this.huoYuanDiZhi = huoYuanDiZhi == null ? null : huoYuanDiZhi.trim();
    }

    public String getBeiyong1() {
        return beiyong1;
    }

    public void setBeiyong1(String beiyong1) {
        this.beiyong1 = beiyong1 == null ? null : beiyong1.trim();
    }

    public String getBeiyong2() {
        return beiyong2;
    }

    public void setBeiyong2(String beiyong2) {
        this.beiyong2 = beiyong2 == null ? null : beiyong2.trim();
    }

    public String getShenhe() {
        return shenhe;
    }

    public void setShenhe(String shenhe) {
        this.shenhe = shenhe == null ? null : shenhe.trim();
    }

    public String getYuanyin() {
        return yuanyin;
    }

    public void setYuanyin(String yuanyin) {
        this.yuanyin = yuanyin == null ? null : yuanyin.trim();
    }

    public String getBeiyong3() {
        return beiyong3;
    }

    public void setBeiyong3(String beiyong3) {
        this.beiyong3 = beiyong3 == null ? null : beiyong3.trim();
    }

    public String getBeiyong4() {
        return beiyong4;
    }

    public void setBeiyong4(String beiyong4) {
        this.beiyong4 = beiyong4 == null ? null : beiyong4.trim();
    }

    public String getBeiyong5() {
        return beiyong5;
    }

    public void setBeiyong5(String beiyong5) {
        this.beiyong5 = beiyong5 == null ? null : beiyong5.trim();
    }

    public Integer getBumen() {
        return bumen;
    }

    public void setBumen(Integer bumen) {
        this.bumen = bumen;
    }
}