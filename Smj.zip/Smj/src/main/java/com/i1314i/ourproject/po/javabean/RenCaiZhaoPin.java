package com.i1314i.ourproject.po.javabean;

import java.util.Date;

public class RenCaiZhaoPin {
    private Integer zhaopinId;

    private String zhiwei;

    private String gongZuoJianJie;

    private String sex;

    private Integer minAge;

    private Integer maxAge;

    private String xueli;

    private Double x;

    private Double y;

    private String beiyong1;

    private String beiyong2;

    private String shenhe;

    private Integer gongZuoDiDian;

    private Double minXinZiDaiYu;

    private Date time;

    private Integer zhaoPinRenShu;

    private String tel;

    private Double maxXinZiDaiYu;

    private String yuanyin;

    private String beiyong3;

    private String beiyong4;

    private String beiyong5;

    private Integer bumen;

    //额外增加
    private String jieDaoMingCheng;

    private String sheQuMingCheng;

    public String getJieDaoMingCheng() {
        return jieDaoMingCheng;
    }

    public void setJieDaoMingCheng(String jieDaoMingCheng) {
        this.jieDaoMingCheng = jieDaoMingCheng;
    }

    public String getSheQuMingCheng() {
        return sheQuMingCheng;
    }

    public void setSheQuMingCheng(String sheQuMingCheng) {
        this.sheQuMingCheng = sheQuMingCheng;
    }

    public Integer getZhaopinId() {
        return zhaopinId;
    }

    public void setZhaopinId(Integer zhaopinId) {
        this.zhaopinId = zhaopinId;
    }

    public String getZhiwei() {
        return zhiwei;
    }

    public void setZhiwei(String zhiwei) {
        this.zhiwei = zhiwei == null ? null : zhiwei.trim();
    }

    public String getGongZuoJianJie() {
        return gongZuoJianJie;
    }

    public void setGongZuoJianJie(String gongZuoJianJie) {
        this.gongZuoJianJie = gongZuoJianJie == null ? null : gongZuoJianJie.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    public String getXueli() {
        return xueli;
    }

    public void setXueli(String xueli) {
        this.xueli = xueli == null ? null : xueli.trim();
    }

    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }

    public String getBeiyong1() {
        return beiyong1;
    }

    public void setBeiyong1(String beiyong1) {
        this.beiyong1 = beiyong1 == null ? null : beiyong1.trim();
    }

    public String getBeiyong2() {
        return beiyong2;
    }

    public void setBeiyong2(String beiyong2) {
        this.beiyong2 = beiyong2 == null ? null : beiyong2.trim();
    }

    public String getShenhe() {
        return shenhe;
    }

    public void setShenhe(String shenhe) {
        this.shenhe = shenhe == null ? null : shenhe.trim();
    }

    public Integer getGongZuoDiDian() {
        return gongZuoDiDian;
    }

    public void setGongZuoDiDian(Integer gongZuoDiDian) {
        this.gongZuoDiDian = gongZuoDiDian;
    }

    public Double getMinXinZiDaiYu() {
        return minXinZiDaiYu;
    }

    public void setMinXinZiDaiYu(Double minXinZiDaiYu) {
        this.minXinZiDaiYu = minXinZiDaiYu;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Integer getZhaoPinRenShu() {
        return zhaoPinRenShu;
    }

    public void setZhaoPinRenShu(Integer zhaoPinRenShu) {
        this.zhaoPinRenShu = zhaoPinRenShu;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public Double getMaxXinZiDaiYu() {
        return maxXinZiDaiYu;
    }

    public void setMaxXinZiDaiYu(Double maxXinZiDaiYu) {
        this.maxXinZiDaiYu = maxXinZiDaiYu;
    }

    public String getYuanyin() {
        return yuanyin;
    }

    public void setYuanyin(String yuanyin) {
        this.yuanyin = yuanyin == null ? null : yuanyin.trim();
    }

    public String getBeiyong3() {
        return beiyong3;
    }

    public void setBeiyong3(String beiyong3) {
        this.beiyong3 = beiyong3 == null ? null : beiyong3.trim();
    }

    public String getBeiyong4() {
        return beiyong4;
    }

    public void setBeiyong4(String beiyong4) {
        this.beiyong4 = beiyong4 == null ? null : beiyong4.trim();
    }

    public String getBeiyong5() {
        return beiyong5;
    }

    public void setBeiyong5(String beiyong5) {
        this.beiyong5 = beiyong5 == null ? null : beiyong5.trim();
    }

    public Integer getBumen() {
        return bumen;
    }

    public void setBumen(Integer bumen) {
        this.bumen = bumen;
    }
}