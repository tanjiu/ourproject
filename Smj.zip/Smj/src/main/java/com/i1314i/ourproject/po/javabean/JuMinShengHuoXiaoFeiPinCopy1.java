package com.i1314i.ourproject.po.javabean;

import java.util.Date;

public class JuMinShengHuoXiaoFeiPinCopy1 {
    private Integer juMinShengHuoId;

    private String shangpinMingcheng;

    private String leibie;

    private String guiGeDengJi;

    private String jiLiangDanWei;

    private Double lingShouChaoShiJiaGe;

    private Double lingShouJiShiJiaGe;

    private String caiJiaShiChang;

    private String beizhu;

    private String zhiBiaoJieShi;

    private Date shijian;

    public Integer getJuMinShengHuoId() {
        return juMinShengHuoId;
    }

    public void setJuMinShengHuoId(Integer juMinShengHuoId) {
        this.juMinShengHuoId = juMinShengHuoId;
    }

    public String getShangpinMingcheng() {
        return shangpinMingcheng;
    }

    public void setShangpinMingcheng(String shangpinMingcheng) {
        this.shangpinMingcheng = shangpinMingcheng == null ? null : shangpinMingcheng.trim();
    }

    public String getLeibie() {
        return leibie;
    }

    public void setLeibie(String leibie) {
        this.leibie = leibie == null ? null : leibie.trim();
    }

    public String getGuiGeDengJi() {
        return guiGeDengJi;
    }

    public void setGuiGeDengJi(String guiGeDengJi) {
        this.guiGeDengJi = guiGeDengJi == null ? null : guiGeDengJi.trim();
    }

    public String getJiLiangDanWei() {
        return jiLiangDanWei;
    }

    public void setJiLiangDanWei(String jiLiangDanWei) {
        this.jiLiangDanWei = jiLiangDanWei == null ? null : jiLiangDanWei.trim();
    }

    public Double getLingShouChaoShiJiaGe() {
        return lingShouChaoShiJiaGe;
    }

    public void setLingShouChaoShiJiaGe(Double lingShouChaoShiJiaGe) {
        this.lingShouChaoShiJiaGe = lingShouChaoShiJiaGe;
    }

    public Double getLingShouJiShiJiaGe() {
        return lingShouJiShiJiaGe;
    }

    public void setLingShouJiShiJiaGe(Double lingShouJiShiJiaGe) {
        this.lingShouJiShiJiaGe = lingShouJiShiJiaGe;
    }

    public String getCaiJiaShiChang() {
        return caiJiaShiChang;
    }

    public void setCaiJiaShiChang(String caiJiaShiChang) {
        this.caiJiaShiChang = caiJiaShiChang == null ? null : caiJiaShiChang.trim();
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }

    public String getZhiBiaoJieShi() {
        return zhiBiaoJieShi;
    }

    public void setZhiBiaoJieShi(String zhiBiaoJieShi) {
        this.zhiBiaoJieShi = zhiBiaoJieShi == null ? null : zhiBiaoJieShi.trim();
    }

    public Date getShijian() {
        return shijian;
    }

    public void setShijian(Date shijian) {
        this.shijian = shijian;
    }
}