package com.i1314i.ourproject.po.javabean;

/**
 * @author 叹久
 * @create 2019-03-04 15:28
 */
public class CountType {
    private String type;
    private String total;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
