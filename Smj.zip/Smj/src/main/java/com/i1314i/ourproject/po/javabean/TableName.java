package com.i1314i.ourproject.po.javabean;

/**
 * @author 叹久
 * @create 2018-10-05 16:05
 */
public class TableName {
    private String chengfen;

    public TableName() {
    }

    public TableName(String chengfen) {
        this.chengfen = chengfen;
    }

    public String getChengfen() {
        return chengfen;
    }

    public void setChengfen(String chengfen) {
        this.chengfen = chengfen;
    }
}
