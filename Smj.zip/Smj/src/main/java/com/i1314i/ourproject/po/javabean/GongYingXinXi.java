package com.i1314i.ourproject.po.javabean;

import java.util.Date;

public class GongYingXinXi {
    private Integer gongYingId;

    private String chanPinMingCheng;

    private Double price;

    private String tel;

    private Date time;

    private String faHuoDi;

    private String imageUrl;

    private String chanPinJianJie;

    private String beiyong1;

    private String beiyong2;

    private String shenhe;

    private String yuanyin;

    private String beiyong3;

    private String beiyong4;

    private String beiyong5;

    private Integer bumen;

    private Integer imageId;


    public Integer getGongYingId() {
        return gongYingId;
    }

    public void setGongYingId(Integer gongYingId) {
        this.gongYingId = gongYingId;
    }

    public String getChanPinMingCheng() {
        return chanPinMingCheng;
    }

    public void setChanPinMingCheng(String chanPinMingCheng) {
        this.chanPinMingCheng = chanPinMingCheng == null ? null : chanPinMingCheng.trim();
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getFaHuoDi() {
        return faHuoDi;
    }

    public void setFaHuoDi(String faHuoDi) {
        this.faHuoDi = faHuoDi == null ? null : faHuoDi.trim();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? null : imageUrl.trim();
    }

    public String getChanPinJianJie() {
        return chanPinJianJie;
    }

    public void setChanPinJianJie(String chanPinJianJie) {
        this.chanPinJianJie = chanPinJianJie == null ? null : chanPinJianJie.trim();
    }

    public String getBeiyong1() {
        return beiyong1;
    }

    public void setBeiyong1(String beiyong1) {
        this.beiyong1 = beiyong1 == null ? null : beiyong1.trim();
    }

    public String getBeiyong2() {
        return beiyong2;
    }

    public void setBeiyong2(String beiyong2) {
        this.beiyong2 = beiyong2 == null ? null : beiyong2.trim();
    }

    public String getShenhe() {
        return shenhe;
    }

    public void setShenhe(String shenhe) {
        this.shenhe = shenhe == null ? null : shenhe.trim();
    }

    public String getYuanyin() {
        return yuanyin;
    }

    public void setYuanyin(String yuanyin) {
        this.yuanyin = yuanyin == null ? null : yuanyin.trim();
    }

    public String getBeiyong3() {
        return beiyong3;
    }

    public void setBeiyong3(String beiyong3) {
        this.beiyong3 = beiyong3 == null ? null : beiyong3.trim();
    }

    public String getBeiyong4() {
        return beiyong4;
    }

    public void setBeiyong4(String beiyong4) {
        this.beiyong4 = beiyong4 == null ? null : beiyong4.trim();
    }

    public String getBeiyong5() {
        return beiyong5;
    }

    public void setBeiyong5(String beiyong5) {
        this.beiyong5 = beiyong5 == null ? null : beiyong5.trim();
    }

    public Integer getBumen() {
        return bumen;
    }

    public void setBumen(Integer bumen) {
        this.bumen = bumen;
    }

    public Integer getImageId() {
        return imageId;
    }

    public void setImageId(Integer imageId) {
        this.imageId = imageId;
    }
}